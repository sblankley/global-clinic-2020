# csvWrite.py

import result_trigger

result = result_trigger.run_optimization()
print(result[0])